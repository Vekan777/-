@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V33_ACTING_EXPRESSION.html"
