@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V45_ART_ENGINE.html"
