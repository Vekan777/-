@echo off
start "" "AI_Anime_Factory_V20_3_PRESERVATION.html"
