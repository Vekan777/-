@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V30_UNIFIED_QUALITY_REVIEW.html"
