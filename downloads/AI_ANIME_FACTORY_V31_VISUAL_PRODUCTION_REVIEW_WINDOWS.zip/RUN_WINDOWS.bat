@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V31_VISUAL_PRODUCTION_REVIEW.html"
