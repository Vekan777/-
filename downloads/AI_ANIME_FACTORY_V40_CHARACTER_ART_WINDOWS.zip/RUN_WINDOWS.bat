@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V40_CHARACTER_ART.html"
