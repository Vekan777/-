@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V46_ANIMATION_ENGINE.html"
