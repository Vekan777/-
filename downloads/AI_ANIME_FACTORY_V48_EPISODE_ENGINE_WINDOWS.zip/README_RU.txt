AI ANIME FACTORY V48 / EPISODE PRODUCTION ENGINE / WINDOWS
===========================================================
1. Extract the ENTIRE ZIP into a NEW folder.
2. Double-click RUN_WINDOWS.bat. Chrome/Edge opens the full editor.
3. Go to "Монтаж серий V48" for full timeline preview, credits,
   subtitle exports (SRT/VTT), soundtrack and one-episode WebM.
4. Export FULL portable project JSON with your pictures and audio,
   rename file to PROJECT_INPUT.json, put it next to BAT scripts.
5. Install Python 3.11+ x64 once (https://www.python.org/downloads/windows/).
6. Run SETUP_BATCH_WINDOWS.bat once with internet: Playwright Chromium.
7. Put ffmpeg.exe + ffprobe.exe in tools\ffmpeg\bin\ or PATH.
8. Run RUN_BATCH_WINDOWS.bat for sequential WebM+MP4, subtitles,
   checksum checkpoint and automatic resume from completed episodes.
9. Completed videos appear in OUTPUT folder; restart BAT after failure.
10. Original story, V19 and all V20–V47 are retained.
V48 is real-time 2D Canvas recording, not claimed to be a professional
20-minute broadcast-anime render or automatic high-end art generator.
V49 Unified, V50 Deep QA remain unfinished, 3D after V50 acceptance.
Full Russian guide: source/V48_README_RU.md
