@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
py -3 --version >nul 2>&1
if errorlevel 1 (
 set "PYTHON=python"
) else (
 set "PYTHON=py -3"
)
%PYTHON% --version
if errorlevel 1 (
 echo Python not found. Download Python 3.11+ x64 from https://www.python.org/downloads/windows/
 pause
 exit /b 1
)
echo Installing Python Playwright 1.56.0 and Chromium browser; internet is required.
%PYTHON% -m pip install --user "playwright==1.56.0"
if errorlevel 1 (echo Playwright install failed & pause & exit /b 1)
%PYTHON% -m playwright install chromium
if errorlevel 1 (echo Chromium install failed & pause & exit /b 1)
echo Installation complete. FFmpeg+FFprobe also required for verified MP4.
pause
