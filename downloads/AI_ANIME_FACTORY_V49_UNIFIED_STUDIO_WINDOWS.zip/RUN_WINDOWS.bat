@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V49_UNIFIED_STUDIO.html"
