@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if not exist "PROJECT_INPUT.json" (
 echo Missing PROJECT_INPUT.json! Export full portable JSON from the V48 editor.
 echo Rename it to PROJECT_INPUT.json and place next to RUN_BATCH_WINDOWS.bat.
 pause
 exit /b 2
)
if exist "tools\ffmpeg\bin\ffmpeg.exe" (
 set "PATH=%CD%\tools\ffmpeg\bin;%PATH%"
)
py -3 --version >nul 2>&1
if errorlevel 1 (
 set "PYTHON=python"
) else (
 set "PYTHON=py -3"
)
%PYTHON% --version
if errorlevel 1 (echo Install Python 3.11+ x64 first. & pause & exit /b 1)
%PYTHON% "source\V48_render_anime_v48.py" --html "AI_Anime_Factory_V49_UNIFIED_STUDIO.html" --project "PROJECT_INPUT.json" --out "OUTPUT" --fps 6 --mp4
if errorlevel 1 (
 echo Render error: see V48_RENDER_CHECKPOINT.json under OUTPUT if present.
 pause
 exit /b 1
)
echo Finished: WebM, H264/AAC MP4 and SRT/VTT are under OUTPUT.
pause
