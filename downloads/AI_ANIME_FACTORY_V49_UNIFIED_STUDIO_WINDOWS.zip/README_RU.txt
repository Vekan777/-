AI ANIME FACTORY V49 — UNIFIED 2D PRODUCTION STUDIO / WINDOWS
==============================================================
1. Extract entire ZIP to a NEW folder, do not overwrite V48.
2. Double-click RUN_WINDOWS.bat (Chrome/Edge).
3. Open "Единая студия V49", select an episode and follow:
   Story → Art → Animation → Voice → Subtitles → Episode Export.
4. Download FULL project JSON containing original story, cutouts,
   V46 keyframes and V47 audio before each major edit.
5. Read actual warnings and mark review steps ONLY if you checked them.
   Manual checkboxes do not bypass technical warnings.
6. "Перейти к настоящей записи серии" opens real V48 episode editor.
7. For MP4 season batch: place PROJECT_INPUT.json next to BAT,
   run SETUP_BATCH_WINDOWS.bat (Python 3.11+, internet), then
   RUN_BATCH_WINDOWS.bat with FFmpeg/FFprobe in tools/ffmpeg/bin.
8. OUTPUT folder contains per-episode MP4/WebM and SRT/VTT,
   with resume from checksum-verified completed episodes only.
V49 preserves V19–V48 and complete V48 ZIP under backup/.
V50 remains deep final QA, NOT claimed finished yet. 3D later.
Read source/V49_README_RU.md for FULL Russian instructions.
