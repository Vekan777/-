@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V21_VISUAL_QUALITY.html"
