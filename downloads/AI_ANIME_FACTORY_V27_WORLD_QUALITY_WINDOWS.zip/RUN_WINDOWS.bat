@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V27_WORLD_QUALITY.html"
