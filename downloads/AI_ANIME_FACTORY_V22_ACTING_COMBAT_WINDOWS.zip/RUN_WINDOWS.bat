@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V22_ACTING_COMBAT.html"
