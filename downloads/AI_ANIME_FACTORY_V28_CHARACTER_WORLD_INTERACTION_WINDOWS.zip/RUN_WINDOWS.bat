@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V28_CHARACTER_WORLD_INTERACTION.html"
