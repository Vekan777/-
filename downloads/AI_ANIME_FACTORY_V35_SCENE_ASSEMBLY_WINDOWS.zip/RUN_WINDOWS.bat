@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V35_SCENE_ASSEMBLY.html"
