@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V32_KEYFRAME_READABILITY.html"
