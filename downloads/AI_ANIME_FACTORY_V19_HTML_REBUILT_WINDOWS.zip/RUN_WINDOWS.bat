@echo off
start "" "AI_Anime_Factory_V19.html"
