@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V34_STORYBOARD_CONTINUITY.html"
