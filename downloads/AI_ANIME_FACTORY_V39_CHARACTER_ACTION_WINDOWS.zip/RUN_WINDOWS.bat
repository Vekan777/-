@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V39_CHARACTER_ACTION.html"
