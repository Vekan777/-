@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V23_CHARACTER_QUALITY.html"
