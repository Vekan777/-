AI ANIME FACTORY V44 — TRUE ACTOR KEYPOSES / WINDOWS 10
=========================================================
1. Извлеките весь ZIP в НОВУЮ папку.
2. Запустите RUN_WINDOWS.bat или откройте HTML в Chrome/Edge.
3. Сохраните полный резерв проекта JSON в «Аудит V30».
4. В «Позы персонажей V44» выберите серию и боевую сцену.
5. Настройте стойку, шаг, руки, блок, инерцию и движения ткани.
6. Сохраните. Сравните до/после на одном времени, скачайте PNG.
7. Для фильма со звуком: «Звук / экспорт V36», WAV/MP3/OGG,
   затем «Записать V44 с позами персонажей» (настоящий WebM).
8. Для MP4: CONVERT_MP4_WINDOWS.bat и ffmpeg.exe
   в tools\ffmpeg\bin\ или PATH.
9. Сохраните полный резерв JSON и свои аудиофайлы отдельно.

В архиве есть ВСЕ исходники редакторов V19–V43 и оригинальный V19.
Полный предыдущий ZIP V43 не вложен из-за GitHub 100MiB file cap:
https://github.com/Vekan777/-/releases/download/anime-factory-v43/AI_ANIME_FACTORY_V43_ACTION_DIRECTOR_WINDOWS.zip
Объединённая V7 также сохраняет исторические Windows ZIP.
V44 — процедурный 2D-риг, не 3D и не motion capture.
Полная инструкция: source/V44_README_RU.md.
