@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V44_TRUE_KEYPOSES.html"
