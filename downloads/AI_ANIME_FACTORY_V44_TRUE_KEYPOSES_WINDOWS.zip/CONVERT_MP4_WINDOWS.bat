@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "INPUT=%~1"
if not defined INPUT (
  for %%F in (*.webm) do if not defined INPUT set "INPUT=%%~fF"
)
if not defined INPUT (
  echo Error: WebM not found. Drag your V36 .webm onto this BAT, or put it beside the BAT.
  pause
  exit /b 2
)
if not exist "%INPUT%" (
  echo Error: missing input "%INPUT%"
  pause
  exit /b 2
)
set "FFMPEG="
if exist "%~dp0tools\ffmpeg\bin\ffmpeg.exe" set "FFMPEG=%~dp0tools\ffmpeg\bin\ffmpeg.exe"
if not defined FFMPEG if exist "%~dp0ffmpeg.exe" set "FFMPEG=%~dp0ffmpeg.exe"
if not defined FFMPEG (
  where ffmpeg >nul 2>nul
  if not errorlevel 1 set "FFMPEG=ffmpeg"
)
if not defined FFMPEG (
  echo Error: FFmpeg not found. Add ffmpeg.exe to tools\ffmpeg\bin\ or to PATH.
  pause
  exit /b 3
)
for %%I in ("%INPUT%") do set "OUTPUT=%%~dpnI.mp4"
echo Input: "%INPUT%"
echo Output: "%OUTPUT%"
"%FFMPEG%" -hide_banner -y -i "%INPUT%" -map 0:v:0 -map 0:a? -c:v libx264 -preset veryfast -crf 22 -pix_fmt yuv420p -c:a aac -b:a 160k -movflags +faststart "%OUTPUT%"
if errorlevel 1 (
  echo Error: MP4 conversion failed. See FFmpeg output above.
  pause
  exit /b 1
)
echo MP4 ready: "%OUTPUT%"
pause
