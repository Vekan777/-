@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V29_ANIMATION_COMBAT_POLISH.html"
