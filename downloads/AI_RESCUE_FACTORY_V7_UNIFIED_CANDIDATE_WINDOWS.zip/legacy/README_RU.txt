Реконструкции V1–V6, сделанные с исправленным общим ядром. Исторические ZIP см. github.com/Vekan777/-/tree/main/downloads.
