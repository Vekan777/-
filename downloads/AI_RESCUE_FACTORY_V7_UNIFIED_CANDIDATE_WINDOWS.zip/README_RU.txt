AI RESCUE FACTORY V7 UNIFIED CANDIDATE — WINDOWS 10 x64
========================================================
Это новая объединяющая сборка, а не побайтовая копия прежних ZIP V1–V6.
Включает автономный Python-движок, SQLite, SHA256, ZIP, AI Pipeline,
GUI, исходник AI Anime V19 и кандидат V20.3. Ничего не требует от
серверной файловой среды ChatGPT для местного запуска.

1) Распакуйте ZIP полностью в новую папку на NTFS.
2) Установите Python 3.10+ для Windows x64, если нет.
3) Запустите TEST_V7_WINDOWS.bat; дождитесь SELFTEST PASS.
4) Запустите RUN_V7_WINDOWS.bat для графического интерфейса.
5) Готовые ZIP находятся в releases/default, копии backups/default.
6) Для импорта исходных файлов старого проекта в GUI нажмите
   «Перенос проекта V1–V6». Движок не перезаписывает оригиналы.
7) Старые архивы V1–V6 лежат в legacy. Для них применён общий
   исправленный исходник V7; прежние архивы в GitHub downloads сохранены.
8) V19 и V20.3 открываются из GUI. V19 сохраняется в backup.
9) Команды:
   py -3 rescue-engine\unified_v7.py selftest
   py -3 rescue-engine\unified_v7.py doctor
   py -3 rescue-engine\unified_v7.py release
   py -3 rescue-engine\unified_v7.py backup
   py -3 rescue-engine\unified_v7.py bundle-verify "V7.zip"
   py -3 rescue-engine\unified_v7.py legacy-import "old.zip"
   py -3 rescue-engine\unified_v7.py migrate-files "old\workspace\default\files"

ПРЕДЕЛЫ: это резервный инструмент файлов/архивов, а не полноценная
нейросеть анимации и не замена ChatGPT. Восстановленный V20.3 — кандидат,
а не проверенный профессиональный редактор. Из истории чата не перенесены
большие исходные MP4 и 36MB ZIP примеров V19.
РЕАЛЬНЫЕ Windows/Linux QA тесты V7 должны пройти в GitHub Actions.
