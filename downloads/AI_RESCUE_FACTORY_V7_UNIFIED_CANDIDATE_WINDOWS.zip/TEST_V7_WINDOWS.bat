@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (python rescue-engine\engine.py selftest && python rescue-engine\unified_v7.py selftest) else (py -3 rescue-engine\engine.py selftest && py -3 rescue-engine\unified_v7.py selftest)
pause
