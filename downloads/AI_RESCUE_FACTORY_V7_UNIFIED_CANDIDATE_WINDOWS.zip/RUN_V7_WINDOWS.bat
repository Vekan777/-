@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (python gui_v7.py) else (py -3 gui_v7.py)
pause
