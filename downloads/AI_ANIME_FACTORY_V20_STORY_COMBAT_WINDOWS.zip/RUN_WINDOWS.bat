@echo off
cd /d "%~dp0"
start "" "AI_Anime_Factory_V20_STORY_COMBAT.html"
