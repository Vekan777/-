@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V41_SILHOUETTE_STUDIO.html"
