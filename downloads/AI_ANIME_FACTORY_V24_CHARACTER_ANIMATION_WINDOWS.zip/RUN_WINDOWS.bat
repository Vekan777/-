@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V24_CHARACTER_ANIMATION.html"
