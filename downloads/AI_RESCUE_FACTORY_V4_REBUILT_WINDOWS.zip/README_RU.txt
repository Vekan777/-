AI Rescue Factory V4 — REBUILT source ZIP
Windows 10 x64. Python 3.10+.
Распакуйте и запустите RUN_WINDOWS.bat.
Задания ArtifactBridgeJob/1 создают файлы, но не исполняют код.
Версия реконструирована, это не точная прежняя браузерная копия.
