@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V43_ACTION_DIRECTOR.html"
