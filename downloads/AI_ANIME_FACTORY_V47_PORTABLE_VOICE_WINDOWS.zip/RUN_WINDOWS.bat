@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V47_PORTABLE_VOICE.html"
