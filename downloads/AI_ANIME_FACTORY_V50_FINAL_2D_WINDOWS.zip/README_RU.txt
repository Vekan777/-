AI ANIME FACTORY V50 FINAL 2D / WINDOWS 10 X64
================================================
1. Extract the complete ZIP into a NEW directory. Do not overwrite V49.
2. Double-click RUN_WINDOWS.bat, or open AI_Anime_Factory_V50_FINAL_2D.html
   in Chrome/Edge. No Python needed for browser-side story/art/animation.
3. Make the FULL project JSON backup before any edits.
4. 'Единая студия V49' is the real six-stage production workflow.
5. 'ФИНАЛЬНАЯ QA V50' audits story, cast IDs, PNG asset integrity,
   cutout keyframe order, audio/mouth amplitude, subtitles, credits and
   per-episode production. Resolve critical errors before releasing.
6. Export final report JSON and full asset/voice/animation project JSON.
7. Human signoff is MANUAL: review EVERY episode and rights to every asset.
8. Produce a real WebM from V48, listen to and watch the final movie.
9. Batch H264/AAC MP4 and SRT/VTT: save PROJECT_INPUT.json next to
   RUN_BATCH_WINDOWS.bat, install Python 3.11+ x64, run
   SETUP_BATCH_WINDOWS.bat (Playwright Chromium) with Internet.
10. Provide your extracted ffmpeg.exe and ffprobe.exe at
    tools\ffmpeg\bin\ (or put both in PATH).
11. Run RUN_BATCH_WINDOWS.bat. OUTPUT has WebM, MP4, SRT, VTT and
    V48_RENDER_CHECKPOINT.json (resume per completed episode).
12. Preserve backup and all original copyrighted/licensed media.
TECHNICAL QA PASS != FINISHED PROFESSIONAL ART. V46 is cutout animation,
V47 lip movement is waveform/RMS, not phoneme recognition.
The series' artistic quality and intellectual property require human review.
This is FINAL V50 — no invented V51. Separate 3D Edition after acceptance.
Full Russian guide: source/V50_README_RU.md
