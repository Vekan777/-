@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V50_FINAL_2D.html"
