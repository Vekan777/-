@echo off
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (python launch.py selftest) else (py -3 launch.py selftest)
pause
