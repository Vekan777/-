@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V37_SUBTITLES_DELIVERY.html"
