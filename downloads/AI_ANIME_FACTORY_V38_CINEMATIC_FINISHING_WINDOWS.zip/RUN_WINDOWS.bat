@echo off
setlocal
cd /d "%~dp0"
start "" "AI_Anime_Factory_V38_CINEMATIC_FINISHING.html"
